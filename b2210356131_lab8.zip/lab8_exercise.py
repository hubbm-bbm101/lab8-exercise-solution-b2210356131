import sys
import os

os.chdir('C:\\Users\\barki\\Desktop')
names_2_search_4 = 'Emre,Habibi'

names_listed = names_2_search_4.replace(','," ").split()
lines_listed = []

with open('students.txt', "r") as mmm :
    for line in mmm :
        line_prime_splitted = line.replace(":",',').split(",")
        line_splitted = line.replace(":",",").replace(','," ,").strip(",").split()
        lines_listed.append(line_splitted)
        for name in names_listed : 
            name == line_splitted[0] 
            print("Name : {}".format(line_prime_splitted[0]) + ', ' + "University : {a},{b}".format(a = line_prime_splitted[1] , b = line_prime_splitted[2]))
    print(lines_listed)      